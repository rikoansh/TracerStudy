<div class="carousel-inner">
        <div class="item active">
          <img src="themes/img/slide1.png" alt="...">
          <div class="carousel-caption">
              <!--h3>Caption Text</h3-->
          </div>
        </div>
        <div class="item">
          <img src="themes/img/slide2.png" alt="...">
        </div>
        <div class="item">
          <img src="themes/img/slide3.png" alt="...">
        </div>
      </div>