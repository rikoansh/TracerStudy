<a class="dropdown-toggle" data-toggle="dropdown" href="#">
    <i class="fa fa-user fa-3x"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="{{route('admin::setting')}}"><i class="fa fa-sign-out fa-fw"></i>Setting Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="{{route('getLogout')}}"><i class="fa fa-sign-out fa-fw"></i>Logout</a>
                        </li>
                    </ul>
                    <!-- end dropdown-user -->