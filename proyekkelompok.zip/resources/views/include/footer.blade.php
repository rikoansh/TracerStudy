<div class="fill"></div>
      <div class="container1">
        <div class="row">
          <div class="col-md-12">
            <p class="text-center">
              Copyright &copy; Fakultas Teknik Universitas Lambung Mangkurat 2015 <br />
              Banjarmasin, Banjarbaru XXXXX | email: blank@unlam.ac.id | Phone: (XXXX) XXX XXXX / XXX XXXXX <br />
              Credit Sites | Copyright | Legal <br />

              <span class="visible-print">-= 2015-11-06 16:47:54 =-</span>
            </p>
          </div>
        </div>
      </div>