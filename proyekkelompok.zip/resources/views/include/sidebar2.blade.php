<div class="panel-heading"><strong>Informasi</strong></div>
    <div class="panel-body">
      <p><strong>Akun</strong> dapat dilihat pada bagian informasi kemahaiswaan Fakultas Teknik UNLAM. <br />
      <br />
      Jika Anda belum mendapatkan Akun, silakan hubungi DKAUI-FTUNLAM di <strong>(XXXX) XXX XXXX / XXX XXXX </strong> 
      atau email ke <strong>alumni@ftunlam.ac.id</strong></p>
    </div>