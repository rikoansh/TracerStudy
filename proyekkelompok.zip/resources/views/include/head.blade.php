<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="{{ asset('themes/img/unlam.png')}}">

    <title>Tracer Study :: Fakultas Teknik</title>

    <link rel="stylesheet" href="{{ asset('themes/bootstrap/css/bootstrap-3.1.1.min.css')}}" />
    <link rel="stylesheet" href="{{ asset('themes/bootstrap/css/bootstrap-theme-3.1.1.min.css')}}" />
    <link rel="stylesheet" href="{{ asset('themes/bootstrap/css/dropdowns-enhancement.css')}}" />
    <link rel="stylesheet" href="{{ asset('themes/fontawesome/css/font-awesome-4.2.0.min.css')}}" />
    <link rel="stylesheet" href="{{ asset('themes/fontawesome/source-code-pro.css')}}" />
  <link rel="stylesheet" href="{{ asset('themes/custom.css')}}" />
    <link rel="stylesheet" href="{{ asset('themes/theme.css')}}" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->