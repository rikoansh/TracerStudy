 <div class="panel-heading">
  Alumni terdata program studi
  </div>
  <div class="panel-body">
  
  <table class="table table-hover">
  <tbody>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Sipil</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Arsitektur</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Pertambangan</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Kimia</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Mesin</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Lingkungan</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  <tr>
  <td><img src="themes/img/unlam.png" height="50" width="50"></td>
  <td class="studi"><label>S1 Teknik Informatika</label></td>
   <td class="dua"><p>:</p></td>
   <td class="angka"><label>50</label></td>
  </tr>
  </tbody>
  </table>
 
  </div>
  <div class="panel-footer">
  Perbarui tanggal: xx-xx-xxxx
  </div>